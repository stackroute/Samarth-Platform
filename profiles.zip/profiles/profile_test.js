var app=require('../app');
var expect=require('chai').expect;
var request=require('supertest');


var request=request(app);

describe("Get test suit for Profile section",function()
{
	//it->testcase
	it('Get education section for a given candidate profile',function(done){
		request.get('/').expect(200,done);
	});
	it('Get if qualification section exist for a given candidate profile',function(done){
		request.get('/').expect(200,done);
	});
});

describe("post Qualification Data Testing Suite", function() {

    it('check for duplicate candidate_id while creating profile section first time', function() {

    });

    it('check for duplicate qualifications while adding new profile ', function() {

    });
    it('adding profile for first time ',function(){

    });
    
}); //end of describe

describe("Update profile Data Testing Suite", function() {

    it('check if profile exists while updating a qualification ', function() {

    });

   
    it('update a profile ',function(){

    });
    it('update a profile with invalid data')
}); //end of describe
