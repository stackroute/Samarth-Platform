var profile = require('./profileschema');

function getprofile(candidateId, successCB, errorCB) {
    profile.find({ "candidateid": candidateId }, function(error, result) {
        if (error) {
            console.log(error);
            errorCB(error);
        }

        console.log("Inside get Project Function" + result);
        successCB(result);
    });
};

function createNewprofile(profileobj,candidateid, successCB, errorCB) {
    var projectObj = new profile({

       
        "candidateid": candidateid,  
        "createdOn": profileobj.createdOn,
        "updatedOn": profileobj.updatedOn,
        "createdBy": profileobj.createdBy, 
        "updatedBy": profileobj.updatedBy 
 });

    console.log("About to save a new profile: ", projectObj);

    projectObj.save(function(err, savedObj) {
        if (err) {
            console.log("Error in saving profile: ", err);
            errorCB(err);
        }

        successCB(savedObj);
    });
};

// function modifyprofile(oldProjectObj, candidateid, successCB, errorCB) {

//     project.update({ "candidateid": candidateid }, { $push: { "records": oldProjectObj.records[0] } },
//         function() {
//             successCB("project added")

//         }
//     );
// };

module.exports = {

    createNewprofile: createNewprofile,
    getprofile: getprofile

};
